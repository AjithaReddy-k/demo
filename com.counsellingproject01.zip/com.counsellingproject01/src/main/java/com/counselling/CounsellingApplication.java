package com.counselling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CounsellingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CounsellingApplication.class, args);
	}

}
