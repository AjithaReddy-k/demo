package com.counselling.Exceptions;

import org.springframework.http.HttpStatus;

public class AppApiExceptions //extends RuntimeException {
{
//	private HttpStatus status;
//
//	private String message;
//
//	public AppApiExceptions(HttpStatus status, String message) {
//
//		this.status = status;
//
//		this.message = message;
//
//	}
//
//	public AppApiExceptions(String message, HttpStatus status, String message1) {
//
//		super(message);
//
//		this.status = status;
//
//		this.message = message1;
//
//	}
//
//	public HttpStatus getStatus() {
//
//		return status;
//
//	}
//
//	@Override
//
//	public String getMessage() {
//
//		return message;
//
//	}

}
