package com.counselling.dto;

public class CounsellingResultDto {
	private int enrollId;
	private String enrolledStudentName;
	private String selectedCollegeName;
	private String selectedGroupName;
	
	private String result;

}
